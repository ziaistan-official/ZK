# Compose sequences

The `compose.py` program parses the compose sequences found in this directory
and generates `srcs/juloo.keyboard2/ComposeKeyData.java`.

## `compose/en_US_UTF_8_Compose.pre`

This file is copied from the `xorg` project. Copyright applies.

## `compose/extra.json`
